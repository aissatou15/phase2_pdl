import java.awt.Color;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TestSearch extends JFrame implements ActionListener {

	private static final long serialVersionUID = 1L;

	private Test testDAO;
	private JButton searchButton;
	private JTextField searchText;


	public TestSearch() {

		this.testDAO=new Test();
		this.setTitle("Search a card");
		this.setSize(300, 150);
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		JPanel pan = new JPanel();
		pan.setBackground(Color.WHITE);
		pan.setLayout(new BoxLayout(pan, BoxLayout.PAGE_AXIS));
		this.setContentPane(pan);
		JPanel panel = new JPanel();
		this.getContentPane().add(panel);

		pan.setLayout(null);

		JLabel searchLabel = new JLabel("Search a card :");
		searchLabel.setBounds(10, 30, 100, 25);
		pan.add(searchLabel);

		searchText = new JTextField(20);
		searchText.setBounds(115, 30, 115, 25);
		pan.add(searchText);

		searchButton = new JButton("Search");
		searchButton.setBounds(150, 65, 80, 25);
		pan.add(searchButton);

		searchButton.addActionListener(this);

		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setVisible(true);

	}
	
	 public int getId() {
			
	        return  Integer.parseInt(this.searchText.getText());
	        }

	public void actionPerformed(ActionEvent ae) {
		
			if (ae.getSource() == searchButton) {
			int	id = Integer.parseInt(this.searchText.getText());
			if(testDAO.SearchCard(id) != null) {
				System.out.println(getId());
				JOptionPane.showMessageDialog(this, "votre badge est la !");
			}
	}

}
	
	public static void main(String[] args) {
		new TestSearch();
	}
}
