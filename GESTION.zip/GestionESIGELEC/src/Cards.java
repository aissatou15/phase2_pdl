import java.awt.Color;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JPanel;


public class Cards extends JFrame implements ActionListener{
	
	private static final long serialVersionUID = 1L;
	private JButton createButton;
	private JButton deleteButton;
	private JButton blockButton;
	private JButton unblockButton;

	  public Cards(){  
	
		this.setTitle("Manage cards");
		this.setSize(400,400);
		
		this.setLocationRelativeTo(null) ;
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JPanel pan = new JPanel();
	    pan.setBackground(Color.WHITE);
	    pan.setLayout(new BoxLayout(pan,BoxLayout.PAGE_AXIS));
	    this.setContentPane(pan); 
	    JPanel panel = new JPanel();
		this.getContentPane().add(panel);
		
		pan.setLayout(null);
			
			createButton = new JButton("Create a card");
			createButton.setBounds(120, 90, 150, 30);
			pan.add(createButton);
			
			deleteButton = new JButton("Delete a card");
			deleteButton.setBounds(120, 130, 150, 30);
			pan.add(deleteButton);
			
			blockButton = new JButton("Block a card");
			blockButton.setBounds(120, 170, 150, 30);
			pan.add(blockButton);
			
			unblockButton = new JButton("Unblock a card");
			unblockButton.setBounds(120, 210, 150, 30);
			pan.add(unblockButton);
			
			createButton.addActionListener(this);
			deleteButton.addActionListener(this);
			blockButton.addActionListener(this);
			unblockButton.addActionListener(this);
			
			this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			this.setVisible(true);
	  }
	  
	  public void actionPerformed(ActionEvent ae) {
			
			 if(ae.getSource()==blockButton) {
				 dispose();
				  new SearchCard();
			  }else if(ae.getSource()==unblockButton) {
				  dispose();
				  new SearchCardUnblock();
			  }
		}
}