import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Test{
	
	final static String URL = "jdbc:oracle:thin:@localhost:1521:orcl";
	final static String LOGIN = "system";  //exemple BDD1
	final static String PASS = "11qqaazz";
	
	public Test() {
		// chargement du pilote de bases de donn茅es
		try {
			Class.forName("oracle.jdbc.OracleDriver");
		} catch (ClassNotFoundException e) {
			System.err
					.println("Impossible de charger le pilote de BDD, ne pas oublier d'importer le fichier .jar dans le projet");
		}

	}
	
	public int ajouter(Badge badge) {
		Connection con = null;
		PreparedStatement ps = null;
		int retour = 0;

	
		try {

		
			con = DriverManager.getConnection(URL, LOGIN, PASS);
		
			ps = con.prepareStatement("INSERT INTO BADGE_BA (BA_ID, BA_BLOCK) VALUES (?, ?)");
			ps.setInt(1, badge.getIne());
			ps.setInt(2, badge.getBlock());
			retour = ps.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (ps != null)
					ps.close();
			} catch (Exception ignore) {
			}
			try {
				if (con != null)
					con.close();
			} catch (Exception ignore) {
			}
		}
		return retour;

	}
	
public Badge SearchCard(int id) {
		
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		Badge retour = null;

		// connexion �  la base de donn茅es
		try {
			
			
			con = DriverManager.getConnection(URL, LOGIN, PASS);
			ps = con.prepareStatement("SELECT * FROM BADGE_BA WHERE BA_ID=?");
			ps.setInt(1, id);
			
			rs = ps.executeQuery();
			if (rs.next())
				retour = new Badge(rs.getInt("ba_id"),
						rs.getInt("ba_block"));
			
			
		} catch (Exception ee) {
			ee.printStackTrace();
		} finally {
			// fermeture du ResultSet, du PreparedStatement et de la Connexion
			try {
				if (rs != null)
					rs.close();
			} catch (Exception ignore) {
			}
			try {
				if (ps != null)
					ps.close();
			} catch (Exception ignore) {
			}
			try {
				if (con != null)
					con.close();
			} catch (Exception ignore) {
			}
		}
		return retour;

	}

public List<Badge> getListeBadge() {

	Connection con = null;
	PreparedStatement ps = null;
	ResultSet rs = null;
	List<Badge> retour = new ArrayList<Badge>();

	// connexion 脿 la base de donn茅es
	try {

		con = DriverManager.getConnection(URL, LOGIN, PASS);
		ps = con.prepareStatement("SELECT * FROM badge_ba");

		// on ex茅cute la requ锚te
		rs = ps.executeQuery();
		// on parcourt les lignes du r茅sultat
		while (rs.next())
			retour.add(new Badge(rs.getInt("ba_id"), rs
					.getInt("ba_block")));

	} catch (Exception ee) {
		ee.printStackTrace();
	} finally {
		// fermeture du rs, du preparedStatement et de la connexion
		try {
			if (rs != null)
				rs.close();
		} catch (Exception ignore) {
		}
		try {
			if (ps != null)
				ps.close();
		} catch (Exception ignore) {
		}
		try {
			if (con != null)
				con.close();
		} catch (Exception ignore) {
		}
	}
	return retour;

}
	
public static void main(String[] args) throws SQLException {

		Test test = new Test();
		
		int id = 1;
		Badge b = test.SearchCard(id);
		System.out.println(b);
		
	/*	List<Badge> liste = test.getListeBadge();
		// affichage des articles
		for (Badge art : liste) {
			System.out.println(art.toString());
		}
*/
	}

}