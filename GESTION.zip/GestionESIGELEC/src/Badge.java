/**
*Classe Badge
*@author samba-lu
*@version 1.2
*/

   public class Badge {
                         /** 
                          * attribut : numero badge
                          */

	   					  private int ine;
	   					  private int block;

                          /**
                           * getter pour l'attribut numero badge
                           * @return valeur du num�ro du badge
                           */
                           public Badge(int ine, int block){
                        	   this.ine=ine;
                        	   this.block=block;
                           }
                           
                            public int getIne() {
                             return ine;
                             }
                            
                            public int getBlock() {
                                return block;
                                }

                            /**
                             * setter pour l'attribut numero badge
                             * @param emplacement :  nouvelle valeur du num�ro du badge
                             */

                              public void setIne (int ine) {
                               this.ine= ine;

                              }
                              
                              public void setBlock (int block) {
                            	  this.block=block;
                              }
                              
                              public String toString() {
                          		return "Badge id: " + ine + " block situation: " + block;
                          	}
                              
                              
                       }