import java.awt.Color;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class Menu extends JFrame implements ActionListener {

	private static final long serialVersionUID = 1L;
	private JButton peopleButton;
	private JButton placeButton;
	private JButton cardsButton;

	public Menu() {

		this.setTitle("Menu");
		this.setSize(400, 400);

		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		JPanel pan = new JPanel();
		pan.setBackground(Color.WHITE);
		pan.setLayout(new BoxLayout(pan, BoxLayout.PAGE_AXIS));
		this.setContentPane(pan);
		JPanel panel = new JPanel();
		this.getContentPane().add(panel);

		pan.setLayout(null);

		peopleButton = new JButton("Manage people");
		peopleButton.setBounds(120, 90, 150, 30);
		pan.add(peopleButton);

		placeButton = new JButton("Manage place");
		placeButton.setBounds(120, 130, 150, 30);
		pan.add(placeButton);

		cardsButton = new JButton("Manage cards");
		cardsButton.setBounds(120, 170, 150, 30);
		pan.add(cardsButton);

		peopleButton.addActionListener(this);
		placeButton.addActionListener(this);
		cardsButton.addActionListener(this);

		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		this.setVisible(true);
	}

	public void actionPerformed(ActionEvent ae) {

		if (ae.getSource() == cardsButton) {
			dispose();
			new Cards();
		}
	}
}
