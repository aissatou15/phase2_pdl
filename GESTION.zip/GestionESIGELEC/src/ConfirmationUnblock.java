import java.awt.Color;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

public class ConfirmationUnblock extends JFrame implements ActionListener {

	private static final long serialVersionUID = 1L;

	private JButton yesButton;
	private JButton noButton;
	private BadgeDAO monBadgeDAO;
	private int id;

	public ConfirmationUnblock(int id) {

		this.id = id;
		this.monBadgeDAO = new BadgeDAO();
		this.setTitle("Unblock Confirmation");
		this.setSize(400, 200);
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JPanel pan = new JPanel();
		pan.setBackground(Color.WHITE);
		pan.setLayout(new BoxLayout(pan, BoxLayout.PAGE_AXIS));
		this.setContentPane(pan);
		JPanel panel = new JPanel();
		this.getContentPane().add(panel);
		pan.setLayout(null);

		JLabel userLabel = new JLabel("Are you sure you want to unblock this badge?");
		userLabel.setBounds(60, 30, 300, 25);
		pan.add(userLabel);

		yesButton = new JButton("yes");
		yesButton.setBounds(60, 65, 80, 25);
		pan.add(yesButton);

		noButton = new JButton("no");
		noButton.setBounds(220, 65, 80, 25);
		pan.add(noButton);

		yesButton.addActionListener(this);
		noButton.addActionListener(this);

		this.setVisible(true);
	}

	public void actionPerformed(ActionEvent ae) {

		int retour;

		if (ae.getSource() == yesButton) {
			Badge b = new Badge(id, 1);
			retour = monBadgeDAO.debloquer(b);
			if (retour == 1) {
				dispose();
				JOptionPane.showMessageDialog(this, "Your card is unblocked!");
				dispose();
				new Cards();
			} else {
				JOptionPane.showMessageDialog(this, "Your card doesn't exist!", "Erreur", JOptionPane.ERROR_MESSAGE);
			}
		}else if(ae.getSource()==noButton) {
			dispose();
			new Cards();
		}
	}
	
}
