import java.awt.Color;


import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JPasswordField;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Login extends JFrame implements ActionListener{
	
	private static final long serialVersionUID = 1L;
	private JButton loginButton;
	
	  public Login(){  
		  
		this.setTitle("connexion");
		this.setSize(400, 400);
		this.setLocationRelativeTo(null) ;
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		    JPanel pan = new JPanel();
		    pan.setBackground(Color.WHITE);
		    pan.setLayout(new BoxLayout(pan,BoxLayout.PAGE_AXIS));
		    this.setContentPane(pan); 
		    JPanel panel = new JPanel();
			this.getContentPane().add(panel);
		

				pan.setLayout(null);
				JLabel userLabel = new JLabel("User");
				userLabel.setBounds(90, 125,95, 25);
				pan.add(userLabel);

				JTextField userText = new JTextField(20);
				userText.setBounds(180, 125, 95, 25);
				pan.add(userText);
				
				JLabel passwordLabel = new JLabel("Password");
				passwordLabel.setBounds(90, 155, 135, 25);
				pan.add(passwordLabel);

				JPasswordField passwordText = new JPasswordField(20);
				passwordText.setBounds(180, 155, 95, 25);
				pan.add(passwordText);
				
				
				loginButton = new JButton("login");
				loginButton.setBounds(150, 210, 85, 25);
				pan.add(loginButton);
				
				loginButton.addActionListener(this);
	
				// permet de quitter l'application si on ferme la fenêtre
				this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

				// rendre la fen阾re visible
				this.setVisible(true);
	  }
	  
	  public void actionPerformed(ActionEvent ae) {
		  
			  if(ae.getSource()==loginButton) {
				  dispose();
				  new Menu();
			  }
	  }
	  }