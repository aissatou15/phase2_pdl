import java.awt.Color;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SearchCardUnblock extends JFrame implements ActionListener {

	private static final long serialVersionUID = 1L;

	private BadgeDAO monBadgeDAO;
	private JButton searchButton;
	private JTextField searchText;

	public SearchCardUnblock() {

		this.monBadgeDAO = new BadgeDAO();
		this.setTitle("Search a blocked card");
		this.setSize(300, 150);
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JPanel pan = new JPanel();
		pan.setBackground(Color.WHITE);
		pan.setLayout(new BoxLayout(pan, BoxLayout.PAGE_AXIS));
		this.setContentPane(pan);
		JPanel panel = new JPanel();
		this.getContentPane().add(panel);

		pan.setLayout(null);

		JLabel searchLabel = new JLabel("Search a card :");
		searchLabel.setBounds(10, 30, 100, 25);
		pan.add(searchLabel);

		searchText = new JTextField(20);
		searchText.setBounds(115, 30, 115, 25);
		pan.add(searchText);

		searchButton = new JButton("Search");
		searchButton.setBounds(150, 65, 80, 25);
		pan.add(searchButton);

		searchButton.addActionListener(this);

		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setVisible(true);

	}

	public void actionPerformed(ActionEvent ae) {
		int retour;
		int id;

		try {
			if (ae.getSource() == searchButton) {
				id = Integer.parseInt(this.searchText.getText());
				retour = monBadgeDAO.SearchCards(id);
				if (retour !=-1) {
					if(retour==0) {
						JOptionPane.showMessageDialog(this, "Your card is already unblocked!");
						dispose();
						new Cards();
					}else {
					dispose();
					new ConfirmationUnblock(id);
					}
					
				}else {
					JOptionPane.showMessageDialog(this, "Your card doesn't exist!", "Erreur",
							JOptionPane.ERROR_MESSAGE);
			}
			}
		}catch (Exception e) {
			JOptionPane.showMessageDialog(this, "Please try again, your id doesn't adapt..", "Erreur",
					JOptionPane.ERROR_MESSAGE);
		}
	}

}
