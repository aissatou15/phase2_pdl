import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Classe d'acces aux donnees contenues dans la table article
 * 
 * @author samba-lu
 * @version 1.2
 * */
public class BadgeDAO {
	
	/**
	 * Parametres de connexion �  la base de donn茅es oracle URL, LOGIN et PASS
	 * sont des constantes
	 */
	final static String URL = "jdbc:oracle:thin:@localhost:1521:orcl";
	final static String LOGIN = "system";  //exemple BDD1
	final static String PASS = "11qqaazz";   //exemple BDD1

	
	/**
	 * Constructeur de la classe
	 * 
	 */
	public BadgeDAO() {
		// chargement du pilote de bases de donn茅es
		try {
			Class.forName("oracle.jdbc.OracleDriver");
		} catch (ClassNotFoundException e) {
			System.err
					.println("Impossible de charger le pilote de BDD, ne pas oublier d'importer le fichier .jar dans le projet");
		}

	}

	public int bloquer(Badge badge) {
		Connection con = null;
		PreparedStatement ps = null;
		int retour = 0;

		// connexion �  la base de donn茅es
		try {

			
			con = DriverManager.getConnection(URL, LOGIN, PASS);
			
			ps = con.prepareStatement("UPDATE BADGE_BA SET BA_BLOCK=1 WHERE BA_ID=? ");
			ps.setInt(1, badge.getIne());
			
			retour = ps.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// fermeture du preparedStatement et de la connexion
			try {
				if (ps != null)
					ps.close();
			} catch (Exception ignore) {
			}
			try {
				if (con != null)
					con.close();
			} catch (Exception ignore) {
			}
		}
		return retour;

	}
	
	
	public int debloquer(Badge badge) {
		Connection con = null;
		PreparedStatement ps = null;
		int retour = 0;

		try {

			con = DriverManager.getConnection(URL, LOGIN, PASS);
			ps = con.prepareStatement("UPDATE BADGE_BA SET BA_BLOCK=0 WHERE BA_ID=? ");
			ps.setInt(1, badge.getIne());
			
			retour = ps.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (ps != null)
					ps.close();
			} catch (Exception ignore) {
			}
			try {
				if (con != null)
					con.close();
			} catch (Exception ignore) {
			}
		}
		return retour;

	}
	
	public int SearchCards(int id) {
		
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		int retour = 0;

		// connexion �  la base de donn茅es
		try {
			con = DriverManager.getConnection(URL, LOGIN, PASS);
			ps = con.prepareStatement("SELECT BA_BLOCK FROM BADGE_BA WHERE BA_ID=?");
			ps.setInt(1, id);
			
			rs = ps.executeQuery();
			if (rs.next())
				retour =rs.getInt("ba_block");
			
			
		} catch (Exception ee) {
			ee.printStackTrace();
		} finally {
			// fermeture du ResultSet, du PreparedStatement et de la Connexion
			try {
				if (rs != null)
					rs.close();
			} catch (Exception ignore) {
			}
			try {
				if (ps != null)
					ps.close();
			} catch (Exception ignore) {
			}
			try {
				if (con != null)
					con.close();
			} catch (Exception ignore) {
			}
		}
		return retour;

	}
}